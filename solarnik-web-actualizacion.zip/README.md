# SOLARNIK · sitio web

Sitio estático de SOLARNIK (IN-ELEC SpA), con calculadora solar netbilling y formulario de contacto.

- `index.html`: página principal.
- `privacidad.html`: política de privacidad.
- `supabase/schema.sql`: tabla `leads` con RLS (el público solo puede insertar).
- `supabase/latido_y_hsp.sql`: función `ping()` de solo lectura y tabla `hsp_cache` (RLS forzado, sin acceso público).
- `supabase/hsp_pgnet.sql`: funciones `hsp_iniciar()` y `hsp_resultado()` (solo `service_role`) que consultan al Ministerio con `pg_net` desde la base de datos. La Edge Function no alcanza a api.minenergia.cl; la base de datos sí.
- `supabase/functions/hsp/`: Edge Function que recibe las coordenadas, usa la caché y pide el dato a esas funciones. La API key va en Supabase Vault (secreto `minenergia_api_key`), no en la función.
- `.github/workflows/latido.yml`: latido diario que evita la pausa del proyecto Supabase gratuito.

## Reglas de seguridad
1. RLS activado en todas las tablas; sin políticas de lectura, modificación ni borrado para el público.
2. En el navegador solo va la clave pública `anon` de Supabase. La clave `service_role` y la API key del Ministerio NUNCA van en este repositorio: van en funciones de servidor (Supabase Edge Functions, en secretos).
3. Antes de lanzar: prueba de ataque y corrección de hallazgos.

## Publicación
GitHub Pages: Settings → Pages → Branch `main` / root.
