-- SOLARNIK · salida al Ministerio por pg_net (la Edge Function no alcanza api.minenergia.cl; la base de datos sí)
-- Pegar completo en Supabase > SQL Editor y ejecutar UNA vez.

create extension if not exists pg_net;

-- Encola la consulta al Ministerio. Devuelve el id de la solicitud (o null si falta la clave en Vault).
create or replace function public.hsp_iniciar(p_body jsonb)
returns bigint
language plpgsql
security definer
set search_path = ''
as $$
declare
  k  text;
  id bigint;
begin
  select decrypted_secret into k from vault.decrypted_secrets where name = 'minenergia_api_key' limit 1;
  if k is null then return null; end if;
  select net.http_post(
    url     := 'https://api.minenergia.cl/api/proxy',
    body    := p_body,
    headers := jsonb_build_object('Content-Type','application/json','Accept','*/*','Authorization','Token ' || k),
    timeout_milliseconds := 25000
  ) into id;
  return id;
end $$;

-- Lee la respuesta. Devuelve null mientras no llegue.
create or replace function public.hsp_resultado(p_id bigint)
returns jsonb
language sql
security definer
set search_path = ''
as $$
  select jsonb_build_object('status', r.status_code, 'timed_out', coalesce(r.timed_out,false),
                            'error', r.error_msg, 'content', r.content)
  from net._http_response r where r.id = p_id;
$$;

-- Solo la Edge Function (clave de servicio) puede usarlas. El público no.
revoke all on function public.hsp_iniciar(jsonb)  from public, anon, authenticated;
revoke all on function public.hsp_resultado(bigint) from public, anon, authenticated;
grant execute on function public.hsp_iniciar(jsonb)  to service_role;
grant execute on function public.hsp_resultado(bigint) to service_role;
