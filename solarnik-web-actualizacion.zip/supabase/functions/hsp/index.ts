// SOLARNIK · Edge Function "hsp"
// Intermediaria entre la calculadora y la API de Energías Renovables del Ministerio de Energía.
// La API key vive solo en Supabase Vault (minenergia_api_key). Nunca llega al navegador.
// Entrada:  POST { "lat": -32.405, "lon": -71.405 }
// Salida:   { "hsp_junio": 3.43, "perfil": [12 valores, HSP por mes], "fuente": "api" | "cache" }
import { createClient } from "jsr:@supabase/supabase-js@2";

const ORIGENES = new Set(["https://cristian-seco.github.io", "https://solarnik.cl", "https://www.solarnik.cl"]);
const TOPE_DIARIO = 300; // consultas nuevas al Ministerio por día (las repetidas salen de la caché)

function cors(origen: string | null) {
  const o = origen && ORIGENES.has(origen) ? origen : "https://cristian-seco.github.io";
  return {
    "Access-Control-Allow-Origin": o,
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "content-type, apikey, authorization, x-client-info, x-region",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin",
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
  };
}

Deno.serve(async (req) => {
  const origen = req.headers.get("origin");
  const h = cors(origen);
  const out = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: h });

  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: h });
  if (req.method !== "POST") return out(405, { error: "metodo" });
  if (!origen || !ORIGENES.has(origen)) return out(403, { error: "origen" });

  // Validación estricta de la entrada
  const len = Number(req.headers.get("content-length") ?? "0");
  if (len > 200) return out(413, { error: "tamano" });
  let lat: unknown, lon: unknown;
  try {
    const txt = await req.text();
    if (txt.length > 200) return out(413, { error: "tamano" });
    ({ lat, lon } = JSON.parse(txt));
  } catch {
    return out(400, { error: "json" });
  }
  if (typeof lat !== "number" || typeof lon !== "number" || !Number.isFinite(lat) || !Number.isFinite(lon)) {
    return out(400, { error: "coordenadas" });
  }
  // Chile continental
  if (lat < -56 || lat > -17.4 || lon < -76 || lon > -66.3) return out(400, { error: "fuera_de_chile" });

  // Se redondea a 0,01° (≈ 1 km): suficiente para la radiación y permite reutilizar consultas
  const la = Math.round(lat * 100) / 100, lo = Math.round(lon * 100) / 100;
  const clave = `${la.toFixed(2)},${lo.toFixed(2)}`;

  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
    auth: { persistSession: false },
  });

  const { data: fila } = await db.from("hsp_cache").select("hsp_junio, perfil").eq("clave", clave).maybeSingle();
  if (fila) return out(200, { hsp_junio: Number(fila.hsp_junio), perfil: fila.perfil.map(Number), fuente: "cache" });

  // Tope diario: protege la cuota asignada por el Ministerio
  const desde = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
  const { count } = await db.from("hsp_cache").select("clave", { count: "exact", head: true }).gte("created_at", desde);
  if ((count ?? 0) >= TOPE_DIARIO) return out(429, { error: "tope_diario" });

  const consulta = {
    action: { action: "series", interval: "month", stat: "mean", tmy: true },
    period: { start: "2004-01-01", end: "2017-12-31" },
    export: { label: "hsp", format: "json" },
    variables: [{
      id: "glb",
      options: {
        label: "GLB",
        stat: "default",
        // Panel fijo inclinado a la latitud (elev1 = 99), orientado al norte
        receptor: { type: "tilt", azimuth: 0, elev1: 99, hsatmax: 45, optimize: false },
      },
    }],
    position: [{ label: "p", type: "point", lat: la, lon: lo }],
  };

  // La salida a internet de las Edge Functions no llega al Ministerio (504), pero la base de datos sí.
  // Por eso la consulta sale por pg_net desde Postgres: hsp_iniciar() la encola y hsp_resultado() la lee.
  // La clave vive en Supabase Vault (minenergia_api_key); aquí ya no se usa.
  const { data: id, error: eIni } = await db.rpc("hsp_iniciar", { p_body: consulta });
  if (eIni) return out(502, { error: "explorador" });
  if (id === null || id === undefined) return out(503, { error: "sin_configurar" });

  let d: unknown;
  const limite = Date.now() + 24000;
  let fin: { status: number | null; timed_out: boolean; error: string | null; content: string | null } | null = null;
  while (Date.now() < limite) {
    await new Promise((r) => setTimeout(r, 600));
    const { data, error } = await db.rpc("hsp_resultado", { p_id: id });
    if (error) return out(502, { error: "explorador" });
    if (data) { fin = data; break; }
  }
  if (!fin || fin.timed_out || fin.status === null) {
    return out(504, { error: "explorador_sin_respuesta", tipo: fin?.timed_out ? "timeout" : "espera" });
  }
  if (fin.status < 200 || fin.status >= 300) return out(502, { error: "explorador", estado: fin.status });
  try {
    d = JSON.parse(fin.content ?? "")?.data?.[0];
  } catch {
    return out(502, { error: "explorador_formato" });
  }
  if (!Array.isArray(d) || d.length !== 12 || !d.every((v) => typeof v === "number" && v > 0 && v < 600)) {
    return out(422, { error: "sin_datos" }); // punto sin cobertura (mar, frontera) o respuesta inesperada
  }

  // La API entrega W/m² promedio del mes; HSP = W/m² × 24 h ÷ 1000 W/m²
  const perfil = (d as number[]).map((v) => Math.round(v * 2.4) / 100);
  const hsp_junio = perfil[5];
  await db.from("hsp_cache").upsert({ clave, hsp_junio, perfil });
  return out(200, { hsp_junio, perfil, fuente: "api" });
});
